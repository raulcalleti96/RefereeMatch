package com.example.refereematch;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class intermedioActivity extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modointermedio);
    }
}
